<!DOCTYPE html>
<html>
<head>
    <title>Login - Internship Portal</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            text-align: center;
            padding-top: 80px;
        }

        .box {
            width: 350px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px #aaa;
        }

        input {
            width: 90%;
            padding: 12px;
            margin: 10px;
        }

        button {
            width: 95%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
        }

        a {
            text-decoration: none;
        }
    </style>
</head>

<body>

<div class="box">

    <h2>College Internship Portal</h2>

    <h3>Student Login</h3>

    <form>
        <input type="email" placeholder="Enter Email" required>

        <input type="password" placeholder="Enter Password" required>

        <button type="submit">Login</button>
    </form>

    <br>

    <a href="register.php">Student Register</a>

    <br><br>

    <a href="index.php">Back to Home</a>

</div>

</body>
</html>