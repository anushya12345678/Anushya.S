<?php
session_start();

if (!isset($_SESSION['users'])) {
    $_SESSION['users'] = [];
}

$page = $_GET['page'] ?? 'home';
$message = '';

if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = strtolower(trim($_POST['email']));
    $password = $_POST['password'];

    if (isset($_SESSION['users'][$email])) {
        $message = "Email already exists!";
        $page = 'register';
    } else {
        $_SESSION['users'][$email] = [
            'name' => $name,
            'password' => password_hash($password, PASSWORD_DEFAULT)
        ];

        header("Location: index.php?page=login");
        exit;
    }
}

if (isset($_POST['login'])) {
    $email = strtolower(trim($_POST['email']));
    $password = $_POST['password'];

    if (
        isset($_SESSION['users'][$email]) &&
        password_verify(
            $password,
            $_SESSION['users'][$email]['password']
        )
    ) {
        session_regenerate_id(true);
        $_SESSION['logged_in'] = true;
        $_SESSION['email'] = $email;

        header("Location: index.php?page=dashboard");
        exit;
    } else {
        $message = "Invalid Email or Password!";
        $page = 'login';
    }
}

if ($page === 'logout') {
    unset($_SESSION['logged_in'], $_SESSION['email']);
    header("Location: index.php");
    exit;
}

if ($page === 'dashboard' && empty($_SESSION['logged_in'])) {
    header("Location: index.php?page=login");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>College Internship Portal</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #edf5ff;
    color: #243b55;
}

nav {
    background: linear-gradient(90deg, #063b8c, #087de1);
    padding: 20px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
}

nav h2 {
    color: white;
    margin: 0;
}

nav a {
    color: white;
    text-decoration: none;
    margin: 8px;
    font-weight: bold;
}

.hero {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 30px;
    padding: 60px 8%;
}

.hero-text {
    flex: 1;
    min-width: 260px;
}

.hero h1 {
    color: #0754aa;
    font-size: 40px;
}

.hero p {
    line-height: 1.8;
    color: #53677e;
}

.hero img {
    width: 100%;
    max-width: 420px;
    border-radius: 18px;
}

.container {
    width: 90%;
    max-width: 430px;
    margin: 50px auto;
    padding: 30px;
    background: white;
    border-radius: 16px;
    box-shadow: 0 8px 25px #174a8020;
    text-align: center;
}

h1 {
    color: #0754aa;
}

input {
    width: 100%;
    padding: 13px;
    margin: 10px 0;
    border: 1px solid #ccd9e8;
    border-radius: 8px;
}

button, .btn {
    display: inline-block;
    width: 100%;
    padding: 13px;
    margin-top: 12px;
    border: none;
    border-radius: 8px;
    background: #0868ce;
    color: white;
    text-decoration: none;
    cursor: pointer;
    font-size: 16px;
}

.btn-light {
    background: #dcecff;
    color: #0754aa;
}

.success {
    color: #168344;
}

.error {
    color: #d62828;
}

.features {
    padding: 30px;
    text-align: center;
}

.cards {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 20px;
}

.card {
    background: white;
    padding: 22px;
    width: 220px;
    border-radius: 12px;
}

footer {
    background: #063b8c;
    color: white;
    text-align: center;
    padding: 20px;
}

@media(max-width: 600px) {
    .hero h1 {
        font-size: 30px;
    }

    nav {
        justify-content: center;
    }
}
</style>
</head>

<body>

<nav>
    <h2>💼 Internship Portal</h2>

    <div>
        <a href="index.php">Home</a>
        <a href="index.php?page=login">Login</a>
        <a href="index.php?page=register">Register</a>

        <?php if (!empty($_SESSION['logged_in'])): ?>
            <a href="index.php?page=dashboard">Dashboard</a>
            <a href="index.php?page=logout">Logout</a>
        <?php endif; ?>
    </div>
</nav>

<?php if ($page === 'home'): ?>

<section class="hero">
    <div class="hero-text">
        <h1>College Internship Portal</h1>

        <p>
            Connect students with valuable internship opportunities.
            Discover companies, apply for internships and build
            your professional career in one place.
        </p>

        <a class="btn" style="width:auto"
           href="index.php?page=register">Get Started</a>

        <a class="btn btn-light" style="width:auto"
           href="index.php?page=login">Student Login</a>
    </div>

    <img
        src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80"
        alt="Laptop and workspace">
</section>

<section class="features">
    <h2>Portal Features</h2>

    <div class="cards">
        <div class="card">
            <h3>📝 Registration</h3>
            <p>Create your account.</p>
        </div>

        <div class="card">
            <h3>💻 Internships</h3>
            <p>Explore opportunities.</p>
        </div>

        <div class="card">
            <h3>📊 Dashboard</h3>
            <p>Access your account.</p>
        </div>
    </div>
</section>

<?php elseif ($page === 'register'): ?>

<div class="container">
    <h1>Register</h1>
    <p>Create your student account.</p>

    <?php if ($message): ?>
        <p class="error"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="POST" action="index.php?page=register">
        <input type="text" name="name"
               placeholder="Full Name" required>

        <input type="email" name="email"
               placeholder="Email Address" required>

        <input type="password" name="password"
               placeholder="Create Password" required>

        <button type="submit" name="register">Register</button>
    </form>

    <p>Already have an account?</p>
    <a href="index.php?page=login">Login Here</a>
</div>

<?php elseif ($page === 'login'): ?>

<div class="container">
    <h1>Student Login</h1>
    <p>Enter your registered details.</p>

    <?php if ($message): ?>
        <p class="error"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="POST" action="index.php?page=login">
        <input type="email" name="email"
               placeholder="Email Address" required>

        <input type="password" name="password"
               placeholder="Password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <p>New student?</p>
    <a href="index.php?page=register">Create Account</a>
</div>

<?php elseif ($page === 'dashboard'): ?>

<div class="container">
    <h1>📊 Dashboard</h1>

    <h2 class="success">Dashboard Successful!</h2>

    <p>Welcome,
        <b><?= htmlspecialchars(
            $_SESSION['users'][$_SESSION['email']]['name']
        ) ?></b>!
    </p>

    <p>You have successfully logged into the portal.</p>

    <a class="btn" href="index.php?page=logout">Logout</a>
</div>

<?php else: ?>

<div class="container">
    <h1>Page Not Found</h1>
    <a class="btn" href="index.php">Go Home</a>
</div>

<?php endif; ?>

<footer>
    College Internship Portal &copy; 2026
</footer>

</body>
</html>