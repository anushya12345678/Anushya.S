# College Internship Application Portal (PHP + MySQL)
1. Copy this folder to `C:\xampp\htdocs\internship-portal` and start Apache + MySQL.
2. Open phpMyAdmin → Import `database.sql` (creates `internship_portal`).
3. Edit `config/database.php` if your MySQL credentials or folder name differ (`BASE`).
4. Visit http://localhost/internship-portal/ — register as a Company to post internships, and as a Student to apply.
Requires PHP 8+ with mysqli and fileinfo enabled (default in XAMPP).
