<?php require '../config/database.php'; need('company'); $c=cmp(); $id=(int)($_GET['id']??$_POST['id']??0); $err='';
$f=['title'=>'Title','required_skills'=>'Required skills','location'=>'Location','duration'=>'Duration (e.g. 3 months)','stipend'=>'Stipend (e.g. 10000/month)','deadline'=>'Deadline'];
$v=array_fill_keys(array_keys($f),''); $v['description']='';
if($id){ $r=one(q('SELECT * FROM internships WHERE id=? AND company_id=?','ii',$id,$c['id'])); if(!$r){header('Location: internships.php'); exit;} $v=$r; }
if($_SERVER['REQUEST_METHOD']==='POST'){ chk();
  foreach($v as $k=>$_) if(isset($_POST[$k])) $v[$k]=trim($_POST[$k]);
  $dt=DateTime::createFromFormat('Y-m-d',$v['deadline']);
  if(!$v['title']||!$v['description']||!$dt||$dt->format('Y-m-d')!==$v['deadline']) $err='Title, description and a valid deadline are required.';
  else{
    if($id) q('UPDATE internships SET title=?,description=?,required_skills=?,location=?,duration=?,stipend=?,deadline=? WHERE id=? AND company_id=?','sssssssii',$v['title'],$v['description'],$v['required_skills'],$v['location'],$v['duration'],$v['stipend'],$v['deadline'],$id,$c['id']);
    else q('INSERT INTO internships(company_id,title,description,required_skills,location,duration,stipend,deadline) VALUES(?,?,?,?,?,?,?,?)','isssssss',$c['id'],$v['title'],$v['description'],$v['required_skills'],$v['location'],$v['duration'],$v['stipend'],$v['deadline']);
    header('Location: internships.php?ok=1'); exit; } }
$title=$id?'Edit Internship':'Add Internship'; include '../includes/header.php'; ?>
<div class="card narrow wide"><h2><?=e($title)?></h2><?php if($err):?><p class="alert"><?=e($err)?></p><?php endif;?>
<form method="post" data-validate><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="id" value="<?=$id?>">
<?php foreach($f as $k=>$lab):?><label><?=e($lab)?></label><input name="<?=$k?>" <?=$k==='deadline'?'type="date"':''?> <?=in_array($k,['title','deadline'])?'required':''?> value="<?=e($v[$k])?>"><?php if($k==='title'):?><label>Description</label><textarea name="description" rows="5" required><?=e($v['description'])?></textarea><?php endif; endforeach;?>
<button class="btn"><?=$id?'Update':'Publish'?></button></form></div>
<?php include '../includes/footer.php'; ?>
