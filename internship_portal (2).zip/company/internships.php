<?php require '../config/database.php'; need('company'); $c=cmp(); $title='My Internships';
if($_SERVER['REQUEST_METHOD']==='POST'){ chk(); q('DELETE FROM internships WHERE id=? AND company_id=?','ii',(int)$_POST['id'],$c['id']); header('Location: internships.php'); exit; }
$list=rows(q('SELECT i.*,(SELECT COUNT(*) FROM applications WHERE internship_id=i.id) n FROM internships i WHERE company_id=? ORDER BY created_at DESC','i',$c['id']));
include '../includes/header.php'; ?>
<h2>My Internships <a class="btn sm" href="add_internship.php">+ New</a></h2><?php if(isset($_GET['ok'])):?><p class="ok">Saved.</p><?php endif;?>
<div class="grid"><?php if(!$list):?><p>No internships posted yet.</p><?php endif; foreach($list as $i):?>
<div class="card"><h3><?=e($i['title'])?></h3><p class="muted">📍 <?=e($i['location'])?> · ⏱ <?=e($i['duration'])?> · Deadline <?=e($i['deadline'])?></p>
<p><a href="applicants.php?internship_id=<?=$i['id']?>"><?=$i['n']?> applicant(s)</a></p>
<a class="btn sm" href="add_internship.php?id=<?=$i['id']?>">Edit</a>
<form method="post" style="display:inline" onsubmit="return confirm('Delete this internship and its applications?')"><input type="hidden" name="t" value="<?=csrf()?>"><input type="hidden" name="id" value="<?=$i['id']?>"><button class="btn sm danger">Delete</button></form></div><?php endforeach;?></div>
<?php include '../includes/footer.php'; ?>
